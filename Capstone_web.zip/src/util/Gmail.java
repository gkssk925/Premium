package util;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;


public class Gmail extends Authenticator{

	@Override

    protected PasswordAuthentication getPasswordAuthentication() {

        return new PasswordAuthentication("azure_5d7cf87787c85f26efc76ace5c4a7e90@azure.com","tmddus96");

    }
	
	
}
