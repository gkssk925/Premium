package util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseUtil {
	
	public static Connection getConnection() {
		try {
			String dbURL = "jdbc:mysql://zoqtmxhs.mysql.database.azure.com/capstone";
			String dbID="premium@zoqtmxhs";
			String dbPassword="tmddus96!";
			Class.forName("com.mysql.jdbc.Driver");

	        return DriverManager.getConnection(dbURL,dbID,dbPassword);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
